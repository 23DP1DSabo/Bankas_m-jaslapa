import Main;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MenuTests {

    @Test
    public void testShowUserMenu() {
        Main.showUserMenu();
    }
}